import os
import sys
import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

#Convert RGB image to grayscale
def rgb2gray(img):
    imgHeight, imgWidth = img.shape[:2]

    #Create numpy array for new image
    imgGray = np.empty([imgHeight, imgWidth], dtype = np.uint8)

    #Iterate through new image and calculate value for each pixel
    for y in range(imgHeight):
        for x in range(imgWidth):
            imgGray[y][x] = int(.1140 * img[y][x][0] + .5871 * img[y][x][1] + .2989 * img[y][x][2])

    return imgGray

#Generate histogram of single channel of image
def histogram (img, nBins, channel):
    #Extract size attributes
    imgHeight, imgWidth = img.shape[:2]

    #Create numpy array to hold histogram data
    resultHist = np.zeros(nBins)

    #Determine bin size in intensity range
    binWidth = 256 / nBins

    for y in range(imgHeight):
        for x in range(imgWidth):
            pixelBin = int(img[y][x][channel] / binWidth)
            resultHist[pixelBin] = resultHist[pixelBin] + 1

    return resultHist

#Generate histogram of masked section of image
def maskedHistogram (img, mask, nBins, channel):
    #Extract size attributes
    imgHeight, imgWidth = img.shape[:2]

    #Create numpy array to hold histogram data
    resultHist = np.zeros(nBins)

    #Determine bin size in intensity range
    binWidth = 256 / nBins

    for y in range(imgHeight):
        for x in range(imgWidth):
            if (mask[y][x][0] != 0):
                pixelBin = int(img[y][x][channel] / binWidth)
                resultHist[pixelBin] = resultHist[pixelBin] + 1

    return resultHist

#Display histogram as bar graph
def displayHist(data, nBins):
    x = np.arange(nBins)
    fig, ax = plt.subplots()
    ax.bar(x, data, width=1, edgecolor="white", linewidth=0.7)

    plt.show()